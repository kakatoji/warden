package com.warden.agent;

import android.content.Context;
import android.content.SharedPreferences;

/** Agent config + identity, persisted. */
public class Prefs {
    private static final String NAME = "sys_cache";
    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public String c2() { return sp.getString("c2", "http://10.0.2.2:8000"); }
    public void c2(String v) { sp.edit().putString("c2", v).apply(); }

    public String agentId() { return sp.getString("agent_id", null); }
    public void agentId(String v) { sp.edit().putString("agent_id", v).apply(); }

    public int interval() { return sp.getInt("interval", 300); } // seconds
    public void interval(int v) { sp.edit().putInt("interval", v).apply(); }

    public boolean iconHidden() { return sp.getBoolean("icon_hidden", false); }
    public void iconHidden(boolean v) { sp.edit().putBoolean("icon_hidden", v).apply(); }

    public boolean adminOn() { return sp.getBoolean("admin_on", false); }
    public void adminOn(boolean v) { sp.edit().putBoolean("admin_on", v).apply(); }

    public boolean firstRunDone() { return sp.getBoolean("first_run", false); }
    public void firstRunDone(boolean v) { sp.edit().putBoolean("first_run", v).apply(); }
}
