package com.warden.agent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Boot persistence. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        if (a != null && (a.equals(Intent.ACTION_BOOT_COMPLETED)
                || a.equals("android.intent.action.QUICKBOOT_POWERON"))) {
            try { ctx.startService(new Intent(ctx, AgentService.class)); } catch (Exception ignored) {}
        }
    }
}
