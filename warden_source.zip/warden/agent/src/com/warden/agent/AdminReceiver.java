package com.warden.agent;

import android.app.admin.DeviceAdminReceiver;

/** Anti-uninstall: admin active makes the app harder to remove. */
public class AdminReceiver extends DeviceAdminReceiver {}
