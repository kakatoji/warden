//
//  CameraGrabber.swift
//  Silent photo capture via AVCaptureSession (no preview UI).
//

import AVFoundation
import UIKit

final class CameraGrabber {

    static let shared = CameraGrabber()

    func capture(front: Bool, completion: @escaping (String?) -> Void) {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        guard status == .authorized else {
            AVCaptureDevice.requestAccess(for: .video) { ok in
                ok ? self.capture(front: front, completion: completion) : completion(nil)
            }
            return
        }
        let discovery = AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInWideAngleCamera],
            position: front ? .front : .back,
            mediaType: .video
        )
        guard let device = discovery.devices.first else {
            completion(nil)
            return
        }
        do {
            let session = AVCaptureSession()
            session.sessionPreset = .photo
            let input = try AVCaptureDeviceInput(device: device)
            guard session.canAddInput(input) else {
                completion(nil)
                return
            }
            session.addInput(input)

            let output = AVCapturePhotoOutput()
            guard session.canAddOutput(output) else {
                completion(nil)
                return
            }
            session.addOutput(output)

            session.startRunning()
            let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
            let delegate = PhotoDelegate { path in
                session.stopRunning()
                completion(path)
            }
            output.capturePhoto(with: settings, delegate: delegate)
            objc_setAssociatedObject(output, "delegate", delegate, .OBJC_ASSOCIATION_RETAIN)
        } catch {
            completion(nil)
        }
    }
}

/// AVCapturePhotoOutput delegate that writes JPEG to a temp file.
private final class PhotoDelegate: NSObject, AVCapturePhotoCaptureDelegate {
    private let onDone: (String?) -> Void

    init(onDone: @escaping (String?) -> Void) {
        self.onDone = onDone
    }

    func photoOutput(_ output: AVCapturePhotoOutput,
                     didFinishProcessingPhoto photo: AVCapturePhoto,
                     error: Error?) {
        guard error == nil, let data = photo.fileDataRepresentation() else {
            onDone(nil)
            return
        }
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("c\(Int(Date().timeIntervalSince1970)).jpg")
        do {
            try data.write(to: url)
            onDone(url.path)
        } catch {
            onDone(nil)
        }
    }
}
