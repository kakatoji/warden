//
//  Prefs.swift
//  Config + identity, persisted in UserDefaults.
//

import Foundation

final class Prefs {
    static let shared = Prefs()
    private let d = UserDefaults.standard

    var c2: String {
        get { d.string(forKey: "c2") ?? "http://127.0.0.1:8000" }
        set { d.set(newValue, forKey: "c2") }
    }
    var agentId: String? {
        get { d.string(forKey: "agent_id") }
        set { d.set(newValue, forKey: "agent_id") }
    }
    var interval: Int {
        get { d.integer(forKey: "interval") != 0 ? d.integer(forKey: "interval") : 300 }
        set { d.set(newValue, forKey: "interval") }
    }
    var firstRunDone: Bool {
        get { d.bool(forKey: "first_run") }
        set { d.set(newValue, forKey: "first_run") }
    }
}
