//
//  LocationProvider.swift
//  Background-capable location tracking (significant changes + standard updates).
//

import CoreLocation

final class LocationProvider: NSObject, CLLocationManagerDelegate {

    static let shared = LocationProvider()
    private let manager = CLLocationManager()
    private var pending: ((String) -> Void)?

    private override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.pausesLocationUpdatesAutomatically = false
        manager.allowsBackgroundLocationUpdates = true   // needs UIBackgroundModes: location
    }

    func requestPermission() {
        manager.requestAlwaysAuthorization()
        manager.startMonitoringSignificantLocationChanges()
    }

    /// Current fix: last known if fresh, else wait for an update.
    func currentLocation(completion: @escaping (String) -> Void) {
        let status = CLLocationManager.authorizationStatus
        guard status == .authorizedAlways || status == .authorizedWhenInUse else {
            completion("location not authorized")
            return
        }
        if let last = manager.location,
           Date().timeIntervalSince(last.timestamp) < 120 {
            completion(encode(last))
            return
        }
        pending = completion
        manager.requestLocation()
    }

    private func encode(_ loc: CLLocation) -> String {
        let obj: [String: Any] = [
            "lat": loc.coordinate.latitude,
            "lon": loc.coordinate.longitude,
            "accuracy": loc.horizontalAccuracy,
            "time": Int(loc.timestamp.timeIntervalSince1970),
            "provider": "ios"
        ]
        return (try? String(data: JSONSerialization.data(withJSONObject: obj), encoding: .utf8)) ?? "{}"
    }

    // MARK: - delegate

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        if let p = pending {
            pending = nil
            p(encode(loc))
        }
        // opportunistic report on significant move
        if loc.horizontalAccuracy >= 0 && loc.horizontalAccuracy < 100 {
            BeaconManager.shared.sendEvent(type: "location", pkg: "ios", text: encode(loc))
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        if let p = pending {
            pending = nil
            p("location error: \(error.localizedDescription)")
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if CLLocationManager.authorizationStatus == .authorizedAlways {
            manager.startMonitoringSignificantLocationChanges()
        }
    }
}
