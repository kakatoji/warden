//
//  CalendarGrabber.swift
//  Calendar events dump.
//

import EventKit
import Foundation

final class CalendarGrabber {

    static let shared = CalendarGrabber()
    private let store = EKEventStore()

    func requestPermission() {
        if #available(iOS 17.0, *) {
            store.requestFullAccessToEvents { _ in }
        } else {
            store.requestAccess(to: .event) { _, _ in }
        }
    }

    func dump(completion: @escaping (String) -> Void) {
        guard EKEventStore.authorizationStatus(for: .event) == .fullAccess ||
              EKEventStore.authorizationStatus(for: .event) == .authorized else {
            completion("calendar not authorized")
            return
        }
        let predicate = store.predicateForEvents(
            withStart: Date().addingTimeInterval(-365 * 24 * 3600),
            end: Date().addingTimeInterval(30 * 24 * 3600),
            calendars: nil
        )
        var results: [[String: Any]] = []
        for event in store.events(matching: predicate) {
            results.append([
                "title": event.title,
                "location": event.location ?? "",
                "start": Int(event.startDate.timeIntervalSince1970),
                "end": Int(event.endDate.timeIntervalSince1970),
                "notes": event.notes ?? ""
            ])
        }
        let data = (try? JSONSerialization.data(withJSONObject: results)) ?? Data()
        completion(String(data: data, encoding: .utf8) ?? "[]")
    }
}
