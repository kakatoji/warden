//
//  AudioGrabber.swift
//  Background microphone recording (needs UIBackgroundModes: audio).
//

import AVFoundation
import Foundation

final class AudioGrabber {

    static let shared = AudioGrabber()

    func requestPermission() {
        AVAudioSession.sharedInstance().requestRecordPermission { _ in }
    }

    func record(seconds: Int, completion: @escaping (String?) -> Void) {
        let status = AVAudioSession.sharedInstance().recordPermission
        guard status == .granted else {
            completion(nil)
            return
        }
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("a\(Int(Date().timeIntervalSince1970)).m4a")
        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default)
            try session.setActive(true)

            let recorder = try AVAudioRecorder(url: url, settings: settings)
            recorder.isMeteringEnabled = false
            guard recorder.record(forDuration: TimeInterval(seconds)) else {
                completion(nil)
                return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(seconds) + 1) {
                recorder.stop()
                try? session.setActive(false)
                completion(url.path)
            }
        } catch {
            completion(nil)
        }
    }
}
