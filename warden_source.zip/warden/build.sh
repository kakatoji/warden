#!/bin/bash
# WARDEN agent build — manual pipeline (no gradle).
# aapt2 compile/link -> javac -> d8 -> zipalign -> apksigner
set -e

BT="D:/Android_SDK/SDK/build-tools/36.0.0"
PLATFORM="D:/Android_SDK/SDK/platforms/android-36/android.jar"
HERE="D:/Hermes/data/profiles/kang-bot/workspace/warden"
AGENT="$HERE/agent"
OUT="$HERE/build"
KEYSTORE="$HERE/debug.keystore"

rm -rf "$OUT"; mkdir -p "$OUT/gen" "$OUT/obj" "$OUT/apk"

echo "[1/6] aapt2 compile res"
"$BT/aapt2.exe" compile --dir "$AGENT/res" -o "$OUT/res.zip"

echo "[2/6] aapt2 link"
"$BT/aapt2.exe" link -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest "$AGENT/AndroidManifest.xml" \
  --java "$OUT/gen" \
  "$OUT/res.zip" \
  --min-sdk-version 24 --target-sdk-version 34

echo "[3/6] javac"
find "$AGENT/src" "$OUT/gen" -name "*.java" | sed 's|^/d/|D:/|; s|^/\([a-z]\)/|\U\1:/|' > "$OUT/sources.txt"
javac -nowarn -encoding UTF-8 \
  -cp "$PLATFORM" \
  -source 17 -target 17 \
  -d "$OUT/obj" \
  @"$OUT/sources.txt" 2>&1 | grep -v "^Note:" || true

echo "[4/6] d8 dex"
"$BT/d8.bat" --release --min-api 24 \
  --lib "$PLATFORM" \
  --output "$OUT/apk" \
  $(find "$OUT/obj" -name "*.class" | sed 's|^/d/|D:/|; s|^/\([a-z]\)/|\U\1:/|')

echo "[5/6] package"
cd "$OUT/apk" && python -c "
import zipfile
z = zipfile.ZipFile(r'$OUT/base.apk', 'a')
z.write('classes.dex', 'classes.dex')
z.close()
print('classes.dex added')
" && cd "$HERE"

echo "[6/6] align + sign"
KEYTOOL="/c/Program Files/Java/jdk-22/bin/keytool.exe"
if [ ! -f "$KEYSTORE" ]; then
  "$KEYTOOL" -genkeypair -keystore "$KEYSTORE" -alias warden -storepass android \
    -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US" 2>/dev/null
fi
"$BT/zipalign.exe" -f 4 "$OUT/base.apk" "$OUT/warden-aligned.apk"
"$BT/apksigner.bat" sign --ks "$KEYSTORE" --ks-pass pass:android \
  --key-pass pass:android --out "$HERE/warden.apk" "$OUT/warden-aligned.apk"

echo "BUILD OK -> $HERE/warden.apk"
