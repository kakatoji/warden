#!/usr/bin/env python3
"""Run C2 server + iOS protocol test in one shot."""
import os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
env = {**os.environ, "PORT": "8766"}
srv = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env,
                       stdout=open(os.path.join(HERE, "server_test.log"), "w"),
                       stderr=subprocess.STDOUT)
try:
    time.sleep(2)
    r = subprocess.run([sys.executable, os.path.join(HERE, "test_ios_protocol.py")])
    sys.exit(r.returncode)
finally:
    srv.terminate()
