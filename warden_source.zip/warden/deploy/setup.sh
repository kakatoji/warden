#!/bin/bash
# WARDEN C2 — VPS bootstrap (Debian 12 / Ubuntu 22.04+)
# Usage: bash setup.sh [port] [domain]
set -e

PORT="${1:-8000}"
DOMAIN="${2:-}"
INSTALL_DIR="/opt/warden"
SERVICE="warden-c2"

echo "==> installing packages"
apt-get update -qq
apt-get install -y -qq python3 python3-venv curl ufw >/dev/null

echo "==> creating $SERVICE user"
id -u "$SERVICE" >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin "$SERVICE"

echo "==> deploying C2 to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cp -r "$(dirname "$0")/../c2/." "$INSTALL_DIR/"
chown -R "$SERVICE:$SERVICE" "$INSTALL_DIR"

echo "==> writing systemd unit"
cat > "/etc/systemd/system/$SERVICE.service" <<EOF
[Unit]
Description=Warden C2
After=network.target

[Service]
Type=simple
User=$SERVICE
WorkingDirectory=$INSTALL_DIR
Environment=PORT=$PORT
ExecStart=/usr/bin/python3 $INSTALL_DIR/server.py
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=full
ReadWritePaths=$INSTALL_DIR

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1
systemctl restart "$SERVICE"

echo "==> firewall"
ufw allow 22/tcp >/dev/null
ufw allow "$PORT"/tcp >/dev/null
if [ -n "$DOMAIN" ]; then
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
fi
ufw --force enable >/dev/null 2>&1

sleep 2
if systemctl is-active --quiet "$SERVICE"; then
  echo "==> C2 LIVE on port $PORT"
  curl -s "http://127.0.0.1:$PORT/api/agents" && echo
else
  echo "==> FAILED — journalctl -u $SERVICE"
  journalctl -u "$SERVICE" --no-pager -n 20
  exit 1
fi

if [ -n "$DOMAIN" ]; then
  echo ""
  echo "==> domain set: $DOMAIN"
  echo "    1. point DNS A record -> this VPS IP"
  echo "    2. install caddy:  apt install -y caddy"
  echo "    3. cp deploy/Caddyfile /etc/caddy/Caddyfile (edit domain)"
  echo "    4. systemctl restart caddy"
  echo "    5. agent c2 URL -> https://$DOMAIN"
fi
echo ""
echo "==> done. manage: systemctl {status|restart|stop} $SERVICE"
