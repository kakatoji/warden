#!/usr/bin/env bash
# Rewrite the C2 URL in BOTH agent sources before a rebuild.
# Usage: bash set_c2.sh http://1.2.3.4:8000 | https://warden.example.com
set -e

URL="${1:?usage: set_c2.sh <c2-url>}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

# Android — Prefs.java default
AND="$ROOT/agent/src/com/warden/agent/Prefs.java"
sed -i "s|return sp.getString(\"c2\", \"[^\"]*\")|return sp.getString(\"c2\", \"$URL\")|" "$AND"

# iOS — Prefs.swift default
IOS="$ROOT/ios/WardenIOS/Prefs.swift"
sed -i "s|d.string(forKey: \"c2\") ?? \"[^\"]*\"|d.string(forKey: \"c2\") ?? \"$URL\"|" "$IOS"

echo "Android: $(grep -o 'return sp.getString("c2", "[^"]*"' "$AND")"
echo "iOS:     $(grep -o 'd.string(forKey: "c2") ?? "[^"]*"' "$IOS")"
echo ""
echo "next: bash build.sh            (android apk)"
echo "      cd ios && xcodegen generate && open WardenIOS.xcodeproj   (ios, on mac)"
